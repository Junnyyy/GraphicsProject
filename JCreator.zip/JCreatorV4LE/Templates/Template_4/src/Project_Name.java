/**
 * @(#)$[PrjName].java
 *
 * JFC $[PrjName] application
 *
 * @author 
 * @version 1.00 $[Year]/$[Month]/$[Day]
 */

public class $[PrjName] {
    
    public static void main(String[] args) {
    	
        // Create application frame.
        $[PrjName]Frame frame = new $[PrjName]Frame();
        
        // Show frame.
        frame.setVisible(true);
    }
}
