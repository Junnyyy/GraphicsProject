/**
 * @(#)$[PrjName].java
 *
 * $[PrjName] application
 *
 * @author 
 * @version 1.00 $[Year]/$[Month]/$[Day]
 */
 
public class $[PrjName] {
    
    public static void main(String[] args) {
    	
    	// TODO, add your application code
    	System.out.println("Hello World!");
    }
}

