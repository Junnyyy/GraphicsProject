/**
 * @(#)$[PrjName].java
 *
 * $[PrjName] Applet application
 *
 * @author 
 * @version 1.00 $[Year]/$[Month]/$[Day]
 */
 
import java.awt.*;
import java.applet.*;

public class $[PrjName] extends Applet {
	
	public void init() {
	}

	public void paint(Graphics g) {
		
		g.drawString("Welcome to Java!!", 50, 60 );
		
	}
}